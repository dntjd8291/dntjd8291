package com.example.employees.dto;

import lombok.Data;

@Data
public class DeptDto {
    private String korDeptCode;
    private String korDeptName;
    private int korPosCnt;
}
