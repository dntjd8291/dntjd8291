use tb_koreait;

create table kor_web(
kor_web_logo varchar(255), -- 로고 이미지 업로드
kor_web_title varchar(100), -- 사이트 title
kor_web_menus varchar(100), -- 사이트 메뉴 => Intro;Course;Project;Contact;Counsel
kor_web_url varchar(255),
kor_web_copyright varchar(255), -- 사이트 카피라이터
kor_web_term text
);

INSERT INTO kor_web VALUES('', '코리아IT아카데미에 오신 것을 환영합니다.', '아카데미소개;IT교육과정;자격증취득과정;국비지원과정;프로젝트;고객상담센터', '코리아IT아카데미는 전국 직영점으로 운영되고 있습니다.', '', '');


UPDATE kor_web SET kor_web_logo = #{korWebLogo}, kor_web_title = #{korWebTitle}, kor_web_url = #{korWebUrl}, kor_web_menus = #{korWebMenus}, kor_web_copyright = #{korWebCopyright}, kor_web_term = #{korWebTerm}